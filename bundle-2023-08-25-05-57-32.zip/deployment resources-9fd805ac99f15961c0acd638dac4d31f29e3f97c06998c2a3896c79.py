import json
import os
import csv
import time
'''
    print('Collect first 2000 deployments')   
    print('grab json from output and manually feed it to https://konklone.io/json/ to generate a csv file.')
    print('project_name is either blank, a valid name or an invalid name. Other than a valid name, default is all projects.')
'''    
    
file_name = '/tmp/data.csv'
file_name2 = '/tmp/data2.csv'
projects = {}
deployment_project = {}
deployments = {}
        
def handler(context, inputs):
    url = '/iaas/api/projects?$select=name,id'
    resp = context.request(url, 'GET', '')
    #print(resp['content'])
    #print(resp['headers'])
    json_resp = {}

    project_id = 0 # all projects are to display
    try:
        json_resp = json.loads(resp['content'])
    except json.decoder.JSONDecodeError as ex:
        print("Error occured while parsing json response: ")
        print(ex)
    t = json_resp['totalElements']
    content = json_resp['content']
    for item in content:
        id = item['id']
        name = item['name']
        #print(id + '; ' + name)
        projects[id] = name
        if name == inputs.get('project_name'):
            project_id = id
    print("No of projects: " + str(t))
    print(projects)
    
    url = '/blueprint/api/blueprints?$select=name,blueprintId'
    resp = context.request(url, 'GET', '')
    #print(resp['content'])
    #print(resp['headers'])
    json_resp = {}
    try:
        json_resp = json.loads(resp['content'])
    except json.decoder.JSONDecodeError as ex:
        print("Error occured while parsing json response: ")
        print(ex)
    t = json_resp['totalElements']
    content = json_resp['content']
    blueprints = {}
    for item in content:
        id = item['id']
        name = item['name']
        #print(id + '; ' + name)
        blueprints[id] = name
    print("No of blueprints: " + str(t))
    print(blueprints)  
    
    if project_id == 0:
        url = '/deployment/api/deployments?$top=2000&$skip=0' # first 2000 deployments
    else:
        url = '/deployment/api/deployments?$top=2000&$skip=0&projects='+ project_id  # specific project_id
        
    resp = context.request(url, 'GET', '')
    #print(resp['content'])
    #print(resp['headers'])
    json_resp = {}
    try:
        json_resp = json.loads(resp['content'])
    except json.decoder.JSONDecodeError as ex:
        print("Error occured while parsing json response: ")
        print(ex)
        return outputs
    t = json_resp['totalElements']
    content = json_resp['content']

    for item in content:
        id = item['id']
        name = item['name']
        projectId = item['projectId']
        #print(id + '; ' + name)
        deployments[id] = name
        deployment_project[id] = projectId
    print("No of deployments: " + str(t))
    print(deployments)
    #print("deploymentId to projectId: ")
    #print(deployment_project)
    report = []
    for k, v in deployments.items():
        data = deploymentDetail(context, k, v)
        if data is None:
            continue
        else:
            report = report + data
        #break # debug
       
    generateCSV(report)

    readFile(file_name)
    outputs = {
      "totalDeployments": t,
      "vmCount": len(report),
      "report": report
    }
    return outputs

def readFile(fileName):

        fileHandler = open(fileName,"r")
        text = fileHandler.read()
        fileHandler.close()
        print(fileName,'content')
        #print(text)
        return text

def generateCSV(array): 
    for i in range(len(array)):
        array[i] = flatten_json(array[i])
        #print(array[i])
        #print("*************")
    fieldnames = []
    for j in range(len(array)):    
        keys = array[j].keys()
        for i in keys:
            if (i not in fieldnames):
                fieldnames.append(i)
    fieldnames.append('project')
    print("report fieldnames:")
    print(fieldnames)
    
    # file_name = '/root/web-root/data.csv'
    # create a CSV file and write the data
    with open(file_name, 'w', newline='') as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames)
        writer.writeheader()
        for row in array:
            deploymentId = row['deploymentId']
            projectId = deployment_project[deploymentId]
            projectName = projects[projectId]
            #print(deploymentId, projectName)
            row['project'] = projectName # map id to name
            row['deploymentName'] = deployments[deploymentId] # map id to name
            writer.writerow(row)
    return 

def flatten_json(y):
        out = {}
        def flatten(x, name=''):
                # If the Nested key-value
                # pair is of dict type
                if type(x) is dict:
                
                        for a in x:
                                flatten(x[a], name + a + '_')
                
                # If the Nested key-value
                # pair is of list type
                elif type(x) is list:
                        i = 0
                        for a in x:
                                flatten(a, name + str(i) + '_')
                                i += 1
                else:   
                        out[name[:-1]] = x
        flatten(y)      
        return out  

def deploymentDetail(context, deploymentId, deploymentName):  
    # collect additional parameters from blueprint to add to report
    # note: vro.workflow deployment does not have catalog data
    #url = '/deployment/api/deployments/' + deploymentId + '?expand=blueprint,catalog,lastRequest,project,resources'
    url = '/deployment/api/deployments/' + deploymentId + '?expand=blueprint'
    resp = context.request(url, 'GET', '')
    #print(resp['content'])
    #print(resp['headers'])
    json_resp = {}
    try:
        json_resp = json.loads(resp['content'])
        if json_resp.get('blueprint') == None:            
            blueprintName = ''
        else:
            blueprintName = json_resp['blueprint']['name']
        createdBy = json_resp['createdBy']
        createdAt = json_resp['createdAt']
        #print(deploymentId, blueprintName, createdBy, createdAt)
    except json.decoder.JSONDecodeError as ex:
        print("Error occured while parsing json response: ")
        print(ex)
        return outputs
    # filter on workload types
    url = '/deployment/api/deployments/' + deploymentId + '/resources?resourceTypes=Cloud.vSphere.Machine,Cloud.AWS.EC2.Instance,Cloud.GCP.Machine,Cloud.Azure.Machine'
    resp = context.request(url, 'GET', '')
    #print(resp['content'])
    print(url)
    json_resp = {}
    try:
        json_resp = json.loads(resp['content'])
    except json.decoder.JSONDecodeError as ex:
        print("Error occured while parsing json response: ")
        print(ex)
        return outputs
    t = json_resp['totalElements']
    print("deployment: " + deploymentName + "; vmCount: " + str(t))
    if t == 0:
        return
    content = json_resp['content']
    
    for item in content:
        item['deploymentId'] = deploymentId # add a new column
        item['deploymentName'] = deploymentId # add a new column
        item['blueprint'] = blueprintName # add a new column
        item['createdBy'] = createdBy # add a new column
        item['createdAt'] = createdAt # add a new column
        for k, v in item['properties'].items(): # expand properties
            item[k] = v
    #print(content)  
    return content
